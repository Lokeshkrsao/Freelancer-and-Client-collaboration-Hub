package com.freelancing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreelancingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
